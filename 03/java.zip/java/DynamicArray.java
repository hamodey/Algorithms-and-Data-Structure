class DynamicArray {
    public OpCounter counter = new OpCounter();
    int nitems;
    int [] storage;
    int [] new1;
    int size2 = 0;
    public DynamicArray(int size) {
        storage = new int[size];
        nitems = 0;
        size2 = size;
    }
    public int length() {
        return nitems;
    }
    public int select(int k) {
        return storage[k];
    }
    public void store(int o, int k) {
        storage[k] = o;
    }
    public void push(int o) {
        extend();
        storage[nitems] = o;
        nitems++;
    }
    public int pop() {
        nitems--;
        return storage[nitems];
    }
    private void extend() {
        new1 = new int[storage.length+1];
        for (int j = 0; j < storage.length; j++ ){
         new1[j] = storage[j];
        }
        storage = new1;
    }
}
