class DynamicArrayCounter {
    public static void main(String args[]) {
	int[] l = {11342};
	for (int i = 0; i < l.length; i++) {
	    DynamicArray a = new DynamicArray(5);
	    for(int n = 0; n < l[i]; n = n + 5) {
        //a.counter.add(n);
        a.counter.add(n+5);
        //a.counter.add(2*n);
        // a.counter.add(n*n);
        a.push(n);
	    }
        System.out.println("" + l[i] + "," + a.counter.report());
	}
    }
}
